Put your 3 real image files in this "images" folder, named:

  profile.jpg   -> used on index.html
  movie.jpg     -> used on movie.html
  book.jpg      -> used on book.html

Any image format works (.jpg, .png, .gif) as long as you update the
"src" attribute in the matching HTML file to the correct filename.

If an image isn't yours, credit it under the image on that page:
"Background image/Photo: {title} by {creator} at {URL}, {CC license abbreviation}."

Delete this README.txt before you zip/submit your final site (it's just
a note for you, not part of the assignment).
